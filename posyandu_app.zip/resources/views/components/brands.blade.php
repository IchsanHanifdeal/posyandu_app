<a class="{{ $class ?? '' }} font-[onest] font-extrabold text-xl">
    Posyandu App
</a>