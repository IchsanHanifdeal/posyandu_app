<x-dashboard.main title="Rujukan">
    
</x-dashboard.main>