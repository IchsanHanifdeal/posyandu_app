<x-dashboard.main title="Skrining Preeklampsia">
    
</x-dashboard.main>