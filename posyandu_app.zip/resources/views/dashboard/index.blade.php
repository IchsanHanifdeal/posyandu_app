<x-dashboard.main title="Dashboard">
    
</x-dashboard.main>