<x-dashboard.main title="Keluarga Berencana">
    <div class="carousel carousel-vertical rounded-box overflow-hidden shadow-lg h-full">
        <div class="carousel-item w-full h-full transition duration-500 ease-in-out transform hover:scale-105">
            <img src="{{ asset('images/informasi/keluarga_berencana.jpg') }}" class="w-full h-full object-cover" 
                alt="Keluarga Berencana" />
        </div>
    </div>
</x-dashboard.main>
