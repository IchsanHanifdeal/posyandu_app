<x-dashboard.main title="Kelas Ibu Hamil">
    <div class="carousel carousel-vertical rounded-box overflow-hidden shadow-lg h-full">
        <div class="carousel-item w-full transition duration-500 ease-in-out transform hover:scale-105">
            <img src="{{ asset('images/informasi/kelas_ibu.jpg') }}" class="w-full h-full object-cover" 
                alt="Kelas Ibu Hamil" />
        </div>
    </div>
</x-dashboard.main>
