<?php

namespace App\Http\Controllers;

use App\Models\Ibu;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\IdentitasAnak;
use App\Models\PerkembanganAnak;
use Illuminate\Support\Facades\Auth;

class PerkembanganAnakController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (Auth::user()->role === 'user') {
            $ibu = Auth::user()->ibu;

            if ($ibu) {
                $anaks = $ibu->identitas_anak;

                $pemeriksaan = PerkembanganAnak::whereIn('id_anak', $anaks->pluck('id_anak'))->get();
            } else {
                $anaks = collect();
                $pemeriksaan = collect();
            }
        } else {
            $anaks = IdentitasAnak::all();
            $pemeriksaan = PerkembanganAnak::all();
        }

        $pemeriksaan->transform(function ($item) {
            // Step 1: Calculate the age in months
            $usia_bulan = \Carbon\Carbon::parse($item->anak->tanggal)->diffInMonths(now());
            $jenis_kelamin = $item->anak->jenis_kelamin; // Assume 'laki-laki' for male or 'perempuan' for female
            $berat_saat_ini = $item->berat_badan;
            $tinggi_saat_ini = $item->tinggi_badan;

            $status_gizi = 'Data tidak lengkap';

            // Step 2: Validate that necessary data is present
            if ($usia_bulan <= 60 && $berat_saat_ini > 0 && $tinggi_saat_ini > 0) {

                // Step 3: Directly include the logic for calculating the mean and SD for weight/height based on age and gender

                // Sample approximations of weight-for-age (using a simplified formula)
                $mean_weight = $jenis_kelamin == 'laki-laki' ? (9 + ($usia_bulan * 0.3)) : (8.5 + ($usia_bulan * 0.28));
                $sd_weight = 1.5; // Standard deviation assumption

                // Sample approximations of height-for-age
                $mean_height = $jenis_kelamin == 'laki-laki' ? (75 + ($usia_bulan * 0.5)) : (73 + ($usia_bulan * 0.45));
                $sd_height = 2; // Standard deviation assumption

                // Sample approximations for weight-for-height (simplified logic)
                $mean_weight_for_height = $tinggi_saat_ini * 0.2;  // Rough approximation
                $sd_weight_for_height = 1.2;  // Standard deviation assumption

                // Step 4: Calculate Z-scores
                $z_score_bb_u = ($berat_saat_ini - $mean_weight) / $sd_weight;
                $z_score_tb_u = ($tinggi_saat_ini - $mean_height) / $sd_height;
                $z_score_bb_tb = ($berat_saat_ini - $mean_weight_for_height) / $sd_weight_for_height;

                // Step 5: Determine nutritional status based on Z-score for weight-for-height
                if ($z_score_bb_tb < -3) {
                    $status_gizi = 'Gizi buruk (Severely Wasted)';
                } elseif ($z_score_bb_tb >= -3 && $z_score_bb_tb < -2) {
                    $status_gizi = 'Gizi kurang (Wasted)';
                } elseif ($z_score_bb_tb >= -2 && $z_score_bb_tb <= 2) {
                    $status_gizi = 'Gizi baik (Normal)';
                } elseif ($z_score_bb_tb > 2) {
                    $status_gizi = 'Gizi lebih (Overweight)';
                }

                // Step 6: Determine stunting status based on Z-score for height-for-age
                if ($z_score_tb_u < -3) {
                    $status_gizi = 'Sangat pendek (Severely Stunted)';
                } elseif ($z_score_tb_u >= -3 && $z_score_tb_u < -2) {
                    $status_gizi = 'Pendek (Stunted)';
                } elseif ($z_score_tb_u >= -2 && $z_score_tb_u <= 2) {
                    $status_gizi = 'Normal';
                } elseif ($z_score_tb_u > 2) {
                    $status_gizi = 'Tinggi (Tall)';
                }
            } else {
                $status_gizi = 'Z-Score tidak tersedia untuk usia > 60 bulan atau data tidak lengkap';
            }

            // Step 7: Attach the status to the child record
            $item->status_gizi = $status_gizi;

            return $item;
        });

        return view('dashboard.perkembangan_anak', [
            'pemeriksaan' => $pemeriksaan, // Display pemeriksaan anak data
            'users' => Ibu::all(), // Get all ibu records for admin/other roles
            'anaks' => $anaks, // Display anak data based on the role
            'id_ibu' => Auth::user()->role === 'user' ? $ibu->id_ibu : null // Set id_ibu for user role
        ]);
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi input form
        $request->validate([
            'id_ibu' => 'required|exists:users,id_user',
            'id_anak' => 'required|exists:identitas_anak,id_anak',
            'pemeriksaan' => 'required|date',
            'tinggi_badan' => 'required|numeric',
            'berat_badan' => 'required|numeric',
            'pemberian_asi' => 'required|string|max:255',
            'pelayanan' => 'required|string|max:255',
            'pemberian_imunisasi' => 'required|string|max:255',
            'catatan' => 'nullable|string|max:500',
        ]);

        // Simpan data ke tabel identitas_anak
        try {
            PerkembanganAnak::create([
                'id_ibu' => $request->id_ibu,
                'id_anak' => $request->id_anak,
                'pemeriksaan' => $request->pemeriksaan,
                'tinggi_badan' => $request->tinggi_badan,
                'berat_badan' => $request->berat_badan,
                'pemberian_asi' => $request->pemberian_asi,
                'pelayanan' => $request->pelayanan,
                'pemberian_imunisasi' => $request->pemberian_imunisasi,
                'catatan' => $request->catatan,
            ]);

            // Redirect dengan notifikasi toast sukses
            return redirect()->back()->with('toast', [
                'type' => 'success',
                'message' => 'Data perkembangan anak berhasil ditambahkan!'
            ]);
        } catch (\Exception $e) {
            // Jika terjadi kesalahan, redirect kembali dengan notifikasi toast error
            return redirect()->back()->with('toast', [
                'type' => 'error',
                'message' => 'Terjadi kesalahan saat menyimpan data perkembangan anak!'
            ]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(PerkembanganAnak $perkembanganAnak)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PerkembanganAnak $perkembanganAnak)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, PerkembanganAnak $perkembanganAnak)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            // Temukan data perkembangan anak berdasarkan ID
            $perkembanganAnak = PerkembanganAnak::findOrFail($id);

            // Hapus data perkembangan anak
            $perkembanganAnak->delete();

            // Redirect dengan notifikasi toast sukses
            return redirect()->back()->with('toast', [
                'type' => 'success',
                'message' => 'Data perkembangan anak berhasil dihapus!'
            ]);
        } catch (\Exception $e) {
            // Jika terjadi kesalahan, redirect kembali dengan notifikasi toast error
            return redirect()->back()->with('toast', [
                'type' => 'error',
                'message' => 'Terjadi kesalahan saat menghapus data perkembangan anak!'
            ]);
        }
    }
}
